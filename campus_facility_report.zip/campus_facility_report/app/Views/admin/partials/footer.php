<footer class="footer">
    <div class="container">
        <p>
            &copy; <?= date('Y') ?> FasilitasKampusKu - Sistem Laporan Kerusakan Fasilitas Kampus
        </p>
        <p>Dikembangkan untuk kemudahan pelaporan fasilitas kampus Di Politeknik Negeri Lampung</p>
    </div>
</footer>